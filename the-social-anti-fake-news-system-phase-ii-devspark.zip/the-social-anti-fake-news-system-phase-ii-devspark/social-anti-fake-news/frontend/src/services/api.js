/**
 * Backend API Service
 * Replaces direct Supabase calls with backend API calls
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api'

// Helper function for API calls
async function apiCall(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`
  const config = {
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    },
    ...options
  }

  // Add auth token if available
  const token = localStorage.getItem('authToken')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }

  try {
    const response = await fetch(url, config)
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: response.statusText }))
      throw new Error(error.message || `HTTP error! status: ${response.status}`)
    }
    
    return await response.json()
  } catch (error) {
    console.error(`API Error [${endpoint}]:`, error)
    throw error
  }
}

// News API
export const newsApi = {
  async getAllNews(filters = {}) {
    const params = new URLSearchParams()
    if (filters.page) params.append('page', filters.page - 1)
    if (filters.size) params.append('size', filters.size)
    if (filters.status) params.append('status', filters.status)
    if (filters.search) params.append('search', filters.search)
    
    const query = params.toString()
    return apiCall(`/news${query ? '?' + query : ''}`)
  },

  async getNewsById(id) {
    return apiCall(`/news/${id}`)
  },

  async searchNews(searchTerm, page = 0, size = 10) {
    return apiCall(`/news/search?searchTerm=${encodeURIComponent(searchTerm)}&page=${page}&size=${size}`)
  },

  async getNewsByStatus(status, page = 0, size = 10) {
    return apiCall(`/news/status/${status}?page=${page}&size=${size}`)
  },

  async createNews(newsData) {
    return apiCall('/news', {
      method: 'POST',
      body: JSON.stringify(newsData)
    })
  },

  async updateNewsStatus(id, status) {
    return apiCall(`/news/${id}/status?status=${status}`, {
      method: 'PUT'
    })
  },

  async deleteNews(id) {
    return apiCall(`/news/${id}`, {
      method: 'DELETE'
    })
  },

  async getStatistics() {
    return apiCall('/news/statistics')
  },

  async getNewsByReporter(reporterId, page = 0, size = 10) {
    return apiCall(`/news/reporter/${reporterId}?page=${page}&size=${size}`)
  }
}

// Comment API
export const commentApi = {
  async getComments(newsId, page = 0, size = 20) {
    return apiCall(`/news/${newsId}/comments?page=${page}&size=${size}`)
  },

  async createComment(newsId, commentData) {
    return apiCall(`/news/${newsId}/comments`, {
      method: 'POST',
      body: JSON.stringify({
        text: commentData.text,
        imageUrl: commentData.imageUrl || null,
        voteType: commentData.voteType || null,
        userId: commentData.userId
      })
    })
  },

  async deleteComment(newsId, commentId) {
    return apiCall(`/news/${newsId}/comments/${commentId}`, {
      method: 'DELETE'
    })
  },

  async restoreComment(newsId, commentId) {
    return apiCall(`/news/${newsId}/comments/${commentId}/restore`, {
      method: 'PUT'
    })
  }
}

// Vote API
export const voteApi = {
  async submitVote(newsId, voteData) {
    return apiCall(`/news/${newsId}/votes`, {
      method: 'POST',
      body: JSON.stringify({
        userId: voteData.userId,
        voteType: voteData.voteType
      })
    })
  },

  async getVotes(newsId) {
    return apiCall(`/news/${newsId}/votes`)
  }
}

// User/Profile API
export const userApi = {
  async getUser(id) {
    return apiCall(`/users/${id}`)
  },

  async getAllUsers() {
    return apiCall('/users')
  },

  async register(userData) {
    return apiCall('/users/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    })
  }
}

// Image Upload API
export const imageApi = {
  async uploadImage(file, folder = 'news') {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('folder', folder)
    
    const url = `${API_BASE_URL}/upload/image`
    const token = localStorage.getItem('authToken')
    
    const response = await fetch(url, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData
    })
    
    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: response.statusText }))
      throw new Error(error.message || 'Image upload failed')
    }
    
    return await response.json()
  }
}

