import { defineStore } from 'pinia'
import { newsApi } from '../services/api'

export const useNewsStore = defineStore('news', {
  state: () => ({
    newsList: [],
    selectedNews: null,
    filter: 'all', // all | fake | notFake | undecided | removed
    searchQuery: '',
    perPage: 6,
    currentPage: 1,
    isLoading: false,
    totalItems: 0
  }),
  getters: {
    totalPages(state){ 
      return Math.max(1, Math.ceil(state.totalItems/state.perPage)) 
    }
  },
  actions: {
    async fetchNews() {
      this.isLoading = true
      try {
        const filters = {
          page: this.currentPage - 1,
          size: this.perPage,
          status: this.filter !== 'all' ? this.filter.toUpperCase() : undefined
        }
        
        if (this.searchQuery) {
          const result = await newsApi.searchNews(this.searchQuery, filters.page, filters.size)
          this.newsList = this.mapNewsItems(result.content || [])
          this.totalItems = result.totalElements || 0
        } else if (filters.status) {
          const result = await newsApi.getNewsByStatus(filters.status, filters.page, filters.size)
          this.newsList = this.mapNewsItems(result.content || [])
          this.totalItems = result.totalElements || 0
        } else {
          const result = await newsApi.getAllNews(filters)
          this.newsList = this.mapNewsItems(result.content || [])
          this.totalItems = result.totalElements || 0
        }
      } catch (error) {
        console.error('Failed to fetch news:', error)
        this.newsList = []
      } finally {
        this.isLoading = false
      }
    },

    async fetchNewsById(id) {
      try {
        const news = await newsApi.getNewsById(id)
        this.selectedNews = this.mapNewsItem(news)
        return this.selectedNews
      } catch (error) {
        console.error('Failed to fetch news:', error)
        return null
      }
    },

    mapNewsItems(items) {
      return items.map(item => this.mapNewsItem(item))
    },

    mapNewsItem(item) {
      return {
        id: item.id,
        title: item.title,
        shortDetail: item.shortDetail,
        fullDetail: item.fullDetail,
        detail: item.fullDetail,
        image: item.imageUrl || '/images/placeholder.jpg',
        reporter: item.reporter?.fullName || item.reporter?.username || 'Anonymous',
        reporterId: item.reporter?.id,
        createdAt: item.createdAt,
        status: (item.status || 'UNDECIDED').toLowerCase(),
        softDeleted: false,
        votes: item.voteCount ? {
          fake: item.voteCount.fakeVotes || 0,
          notFake: item.voteCount.notFakeVotes || 0
        } : { fake: 0, notFake: 0 },
        comments: (item.comments || []).map(c => this.mapComment(c))
      }
    },

    mapComment(comment) {
      return {
        id: comment.id,
        author: comment.user?.fullName || comment.user?.username || 'Anonymous',
        user: comment.user?.fullName || comment.user?.username || 'Anonymous',
        text: comment.text,
        imageUrl: comment.imageUrl || '',
        voteType: comment.voteType,
        vote: comment.voteType ? comment.voteType.toLowerCase().replace('_', '') : null,
        createdAt: comment.createdAt,
        softDeleted: comment.softDeleted || false
      }
    },

    setFilter(f) { 
      this.filter = f
      this.currentPage = 1
      this.fetchNews()
    },
    
    setSearch(q) { 
      this.searchQuery = q
      this.currentPage = 1
      this.fetchNews()
    },
    
    setPerPage(n) { 
      this.perPage = Number(n)
      this.currentPage = 1
      this.fetchNews()
    },
    
    goPage(n) { 
      this.currentPage = Math.max(1, Math.min(n, this.totalPages))
      this.fetchNews()
    },
    
    async setSelectedNews(id) {
      await this.fetchNewsById(id)
    },

    async addNews(payload) {
      try {
        const result = await newsApi.createNews(payload)
        const mapped = this.mapNewsItem(result)
        this.newsList.unshift(mapped)
        return mapped
      } catch (error) {
        console.error('Failed to create news:', error)
        throw error
      }
    }
  }
})

