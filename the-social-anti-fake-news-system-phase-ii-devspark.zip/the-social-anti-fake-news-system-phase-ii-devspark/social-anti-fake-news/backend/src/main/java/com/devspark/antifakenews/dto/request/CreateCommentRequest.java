package com.devspark.antifakenews.dto.request;

import com.devspark.antifakenews.entity.Comment;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Request DTO for creating comments
 * 
 * @author DevSpark Team
 * @version 1.0.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateCommentRequest {
    
    @NotBlank(message = "Comment text is required")
    private String text;
    
    private String imageUrl;
    
    private Comment.VoteType voteType;
    
    @NotNull(message = "User ID is required")
    private java.util.UUID userId;
}
