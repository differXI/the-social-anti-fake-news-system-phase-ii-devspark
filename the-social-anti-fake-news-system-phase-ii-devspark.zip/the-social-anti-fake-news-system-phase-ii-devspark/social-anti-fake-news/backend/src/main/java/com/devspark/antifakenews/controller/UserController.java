package com.devspark.antifakenews.controller;

import com.devspark.antifakenews.dto.UserDto;
import com.devspark.antifakenews.entity.User;
import com.devspark.antifakenews.repository.UserRepository;
import com.devspark.antifakenews.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;
    private final UserRepository userRepository;

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody User user){
        User saved = userService.register(user);
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public ResponseEntity<List<User>> list(){
        return ResponseEntity.ok(userService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<UserDto> getUser(@PathVariable UUID id){
        User user = userService.findById(id).orElseThrow();
        // Map to DTO
        UserDto dto = UserDto.builder()
            .id(user.getId())
            .username(user.getUsername())
            .email(user.getEmail())
            .firstName(user.getFirstName())
            .lastName(user.getLastName())
            .fullName(user.getFullName())
            .imageUrl(user.getImageUrl())
            .role(user.getRole())
            .createdAt(user.getCreatedAt())
            .updatedAt(user.getUpdatedAt())
            .build();
        return ResponseEntity.ok(dto);
    }

    @PutMapping("/{id}/upgrade")
    public ResponseEntity<User> upgrade(@PathVariable UUID id){
        return ResponseEntity.ok(userService.upgradeToAdmin(id));
    }

    @PutMapping("/{id}/make-member")
    public ResponseEntity<User> makeMember(@PathVariable UUID id){
        User u = userService.findById(id).orElseThrow();
        u.setRole(User.Role.MEMBER);
        userRepository.save(u);
        return ResponseEntity.ok(u);
    }
}

