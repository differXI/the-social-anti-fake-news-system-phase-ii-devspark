package com.devspark.antifakenews.controller;

import com.devspark.antifakenews.dto.request.VoteRequest;
import com.devspark.antifakenews.entity.Vote;
import com.devspark.antifakenews.entity.News;
import com.devspark.antifakenews.entity.User;
import com.devspark.antifakenews.repository.VoteRepository;
import com.devspark.antifakenews.repository.NewsRepository;
import com.devspark.antifakenews.repository.UserRepository;
import com.devspark.antifakenews.service.NewsService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST Controller for Vote operations
 * 
 * @author DevSpark Team
 * @version 1.0.0
 */
@RestController
@RequestMapping("/api/news/{newsId}/votes")
@RequiredArgsConstructor
@Slf4j
public class VoteController {

    private final VoteRepository voteRepository;
    private final NewsRepository newsRepository;
    private final UserRepository userRepository;
    private final NewsService newsService;

    /**
     * Submit or update a vote
     * 
     * @param newsId the news ID
     * @param request the vote request
     * @return vote result
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> submitVote(
            @PathVariable Long newsId,
            @RequestBody VoteRequest request) {
        
        log.info("Submitting vote for news ID: {}, user ID: {}, type: {}", 
                newsId, request.getUserId(), request.getVoteType());
        
        News news = newsRepository.findById(newsId)
            .orElseThrow(() -> new RuntimeException("News not found"));
        
        User user = userRepository.findById(request.getUserId())
            .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Check if user already voted
        var existingVote = voteRepository.findByUserIdAndNewsId(request.getUserId(), newsId);
        
        Vote vote;
        if (existingVote.isPresent()) {
            // Update existing vote
            vote = existingVote.get();
            vote.setVoteType(request.getVoteType());
            vote = voteRepository.save(vote);
            log.info("Updated existing vote ID: {}", vote.getId());
        } else {
            // Create new vote
            vote = Vote.builder()
                .news(news)
                .user(user)
                .voteType(request.getVoteType())
                .build();
            vote = voteRepository.save(vote);
            log.info("Created new vote ID: {}", vote.getId());
        }
        
        // Recalculate news status based on votes
        updateNewsStatusFromVotes(newsId);
        
        Map<String, Object> response = new HashMap<>();
        response.put("vote", vote);
        response.put("newsId", newsId);
        
        return ResponseEntity.ok(response);
    }

    /**
     * Get votes for a news article
     * 
     * @param newsId the news ID
     * @return vote statistics
     */
    @GetMapping
    public ResponseEntity<Map<String, Object>> getVotes(@PathVariable Long newsId) {
        log.info("Fetching votes for news ID: {}", newsId);
        
        List<Vote> votes = voteRepository.findByNewsId(newsId);
        
        long fakeCount = votes.stream()
            .filter(v -> v.getVoteType() == Vote.VoteType.FAKE)
            .count();
        
        long notFakeCount = votes.stream()
            .filter(v -> v.getVoteType() == Vote.VoteType.NOT_FAKE)
            .count();
        
        Map<String, Object> response = new HashMap<>();
        response.put("fake", fakeCount);
        response.put("notFake", notFakeCount);
        response.put("total", votes.size());
        response.put("votes", votes);
        
        return ResponseEntity.ok(response);
    }

    /**
     * Update news status based on votes
     */
    private void updateNewsStatusFromVotes(Long newsId) {
        List<Vote> votes = voteRepository.findByNewsId(newsId);
        
        long fakeCount = votes.stream()
            .filter(v -> v.getVoteType() == Vote.VoteType.FAKE)
            .count();
        
        long notFakeCount = votes.stream()
            .filter(v -> v.getVoteType() == Vote.VoteType.NOT_FAKE)
            .count();
        
        News.NewsStatus newStatus;
        if (fakeCount > notFakeCount) {
            newStatus = News.NewsStatus.FAKE;
        } else if (notFakeCount > fakeCount) {
            newStatus = News.NewsStatus.NOT_FAKE;
        } else {
            newStatus = News.NewsStatus.UNDECIDED;
        }
        
        newsService.updateNewsStatus(newsId, newStatus);
    }
}

