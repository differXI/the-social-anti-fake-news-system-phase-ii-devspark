package com.devspark.antifakenews.controller;

import com.devspark.antifakenews.dto.CommentDto;
import com.devspark.antifakenews.dto.request.CreateCommentRequest;
import com.devspark.antifakenews.entity.Comment;
import com.devspark.antifakenews.entity.News;
import com.devspark.antifakenews.entity.User;
import com.devspark.antifakenews.mapper.CommentMapper;
import com.devspark.antifakenews.repository.CommentRepository;
import com.devspark.antifakenews.repository.NewsRepository;
import com.devspark.antifakenews.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/news/{newsId}/comments")
@RequiredArgsConstructor
@Slf4j
public class CommentController {
    private final CommentRepository commentRepository;
    private final NewsRepository newsRepository;
    private final UserRepository userRepository;
    private final CommentMapper commentMapper;

    /**
     * Get comments for a news article
     */
    @GetMapping
    public ResponseEntity<Page<CommentDto>> getComments(
            @PathVariable Long newsId,
            @PageableDefault(size = 20) Pageable pageable) {
        
        log.info("Fetching comments for news ID: {}", newsId);
        
        Page<Comment> comments = commentRepository.findByNewsIdAndSoftDeletedFalse(newsId, pageable);
        Page<CommentDto> commentDtos = comments.map(commentMapper::toDto);
        
        return ResponseEntity.ok(commentDtos);
    }

    /**
     * Create a new comment
     */
    @PostMapping
    public ResponseEntity<CommentDto> createComment(
            @PathVariable Long newsId,
            @RequestBody CreateCommentRequest request) {
        
        log.info("Creating comment for news ID: {}", newsId);
        
        News news = newsRepository.findById(newsId)
            .orElseThrow(() -> new RuntimeException("News not found"));
        
        User user = userRepository.findById(request.getUserId())
            .orElseThrow(() -> new RuntimeException("User not found"));
        
        Comment comment = Comment.builder()
            .news(news)
            .user(user)
            .text(request.getText())
            .imageUrl(request.getImageUrl())
            .voteType(request.getVoteType())
            .softDeleted(false)
            .build();
        
        Comment saved = commentRepository.save(comment);
        log.info("Comment created with ID: {}", saved.getId());
        
        return ResponseEntity.status(HttpStatus.CREATED).body(commentMapper.toDto(saved));
    }

    /**
     * Soft delete a comment
     */
    @DeleteMapping("/{commentId}")
    public ResponseEntity<Void> softDelete(
            @PathVariable Long newsId, 
            @PathVariable Long commentId) {
        
        log.info("Soft deleting comment ID: {} for news ID: {}", commentId, newsId);
        
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("Comment not found"));
        
        if (!comment.getNews().getId().equals(newsId)) {
            throw new RuntimeException("Comment does not belong to this news");
        }
        
        comment.setSoftDeleted(true);
        commentRepository.save(comment);
        
        return ResponseEntity.noContent().build();
    }

    /**
     * Restore a soft-deleted comment
     */
    @PutMapping("/{commentId}/restore")
    public ResponseEntity<Void> restore(
            @PathVariable Long newsId, 
            @PathVariable Long commentId) {
        
        log.info("Restoring comment ID: {} for news ID: {}", commentId, newsId);
        
        Comment comment = commentRepository.findById(commentId)
            .orElseThrow(() -> new RuntimeException("Comment not found"));
        
        if (!comment.getNews().getId().equals(newsId)) {
            throw new RuntimeException("Comment does not belong to this news");
        }
        
        comment.setSoftDeleted(false);
        commentRepository.save(comment);
        
        return ResponseEntity.noContent().build();
    }
}
