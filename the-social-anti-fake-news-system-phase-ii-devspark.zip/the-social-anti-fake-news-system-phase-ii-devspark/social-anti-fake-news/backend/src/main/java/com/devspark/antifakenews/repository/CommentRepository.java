package com.devspark.antifakenews.repository;

import com.devspark.antifakenews.entity.Comment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository interface for Comment entity
 * 
 * @author DevSpark Team
 * @version 1.0.0
 */
@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {

    /**
     * Find comments by news ID
     * 
     * @param newsId the news ID
     * @param pageable pagination information
     * @return page of comments for the specified news
     */
    Page<Comment> findByNewsIdAndSoftDeletedFalse(Long newsId, Pageable pageable);

    /**
     * Find comments by user ID
     * 
     * @param userId the user ID (UUID)
     * @param pageable pagination information
     * @return page of comments by the specified user
     */
    @Query("SELECT c FROM Comment c WHERE c.user.id = :userId AND c.softDeleted = false")
    Page<Comment> findByUserId(@Param("userId") java.util.UUID userId, Pageable pageable);


    /**
     * Count comments by news ID
     * 
     * @param newsId the news ID
     * @return count of comments for the specified news
     */
    long countByNewsIdAndSoftDeletedFalse(Long newsId);

    /**
     * Find comments by vote type
     * 
     * @param voteType the vote type
     * @param pageable pagination information
     * @return page of comments with the specified vote type
     */
    @Query("SELECT c FROM Comment c WHERE c.voteType = :voteType AND c.softDeleted = false")
    Page<Comment> findByVoteTypeAndSoftDeletedFalse(@Param("voteType") Comment.VoteType voteType, Pageable pageable);

    /**
     * Find recent comments
     * 
     * @param pageable pagination information
     * @return page of recent comments
     */
    @Query("SELECT c FROM Comment c WHERE c.softDeleted = false ORDER BY c.createdAt DESC")
    Page<Comment> findBySoftDeletedFalseOrderByCreatedAtDesc(Pageable pageable);

    /**
     * Find all comments for a news article
     * 
     * @param newsId the news ID
     * @return list of all comments for the news
     */
    @Query("SELECT c FROM Comment c WHERE c.news.id = :newsId AND c.softDeleted = false ORDER BY c.createdAt ASC")
    List<Comment> findByNewsIdAndSoftDeletedFalseOrderByCreatedAtAsc(@Param("newsId") Long newsId);
}
