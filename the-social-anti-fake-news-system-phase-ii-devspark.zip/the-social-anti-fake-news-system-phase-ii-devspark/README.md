Group name DevSpark


Team members 

1.Thanachai Naksomboon ID: 662115020 
2.Wanikkasit ID: 652115043


FRONTEND and BACKEND Deploy website 
https://devsparkantifakenewsii.vercel.app/#/
