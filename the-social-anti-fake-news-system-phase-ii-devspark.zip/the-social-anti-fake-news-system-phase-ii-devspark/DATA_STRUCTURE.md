# Data Structure Documentation
## Anti-Fake News System - Database Schema

This document describes the complete data structure that aligns with the PostgreSQL/Supabase database schema.

---

## Database Overview

The system uses PostgreSQL with Supabase authentication. User profiles are managed through Supabase Auth, and the application extends this with a `profiles` table.

---

## Enum Types

```sql
-- News Status
CREATE TYPE news_status AS ENUM ('FAKE', 'NOT_FAKE', 'UNDECIDED');

-- Vote Type
CREATE TYPE vote_type AS ENUM ('FAKE', 'NOT_FAKE');

-- User Role
CREATE TYPE role_type AS ENUM ('READER', 'MEMBER', 'ADMIN');
```

---

## Tables

### 1. `profiles` (User/Profile Table)

Maps to Supabase `auth.users` table. Primary key is UUID from Supabase Auth.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | `uuid` | PRIMARY KEY, FK → `auth.users(id)` | User ID from Supabase Auth |
| `username` | `text` | UNIQUE | Username |
| `email` | `text` | | User email |
| `first_name` | `text` | | First name |
| `last_name` | `text` | | Last name |
| `full_name` | `text` | | Full name (computed) |
| `image_url` | `text` | | Profile image URL |
| `role` | `role_type` | NOT NULL, DEFAULT 'READER' | User role: READER, MEMBER, ADMIN |
| `created_at` | `timestamptz` | NOT NULL, DEFAULT now() | Creation timestamp |
| `updated_at` | `timestamptz` | | Last update timestamp |

**Indexes:**
- Primary key on `id`
- Unique index on `username`

**Relationships:**
- One-to-many with `news` (as `reporter`)
- One-to-many with `comments` (as `user`)
- One-to-many with `votes` (as `user`)

---

### 2. `news` (News Articles Table)

Stores news articles submitted by users.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | `bigint` | PRIMARY KEY, GENERATED | Auto-increment ID |
| `title` | `text` | NOT NULL | News title |
| `short_detail` | `text` | NOT NULL | Short summary/description |
| `full_detail` | `text` | NOT NULL | Full article content |
| `image_url` | `text` | | News image URL (stored in backend storage) |
| `status` | `news_status` | NOT NULL, DEFAULT 'UNDECIDED' | Status: FAKE, NOT_FAKE, UNDECIDED |
| `reporter_id` | `uuid` | NOT NULL, FK → `profiles(id)` | ID of user who submitted |
| `soft_deleted` | `boolean` | NOT NULL, DEFAULT false | Soft delete flag |
| `created_at` | `timestamptz` | NOT NULL, DEFAULT now() | Creation timestamp |
| `updated_at` | `timestamptz` | | Last update timestamp |

**Indexes:**
- Primary key on `id`
- Index on `reporter_id`
- Index on `status`
- Index on `created_at DESC`
- Indexes on `lower(title)`, `lower(short_detail)`, `lower(full_detail)` for search

**Relationships:**
- Many-to-one with `profiles` (reporter)
- One-to-many with `comments`
- One-to-many with `votes`

---

### 3. `comments` (Comments Table)

User comments on news articles. Can include a vote type.

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | `bigint` | PRIMARY KEY, GENERATED | Auto-increment ID |
| `news_id` | `bigint` | NOT NULL, FK → `news(id)` | Related news article |
| `user_id` | `uuid` | NOT NULL, FK → `profiles(id)` | Comment author |
| `text` | `text` | NOT NULL | Comment text |
| `image_url` | `text` | | Optional image URL in comment |
| `vote_type` | `vote_type` | NULL | Optional vote: FAKE, NOT_FAKE |
| `soft_deleted` | `boolean` | NOT NULL, DEFAULT false | Soft delete flag |
| `created_at` | `timestamptz` | NOT NULL, DEFAULT now() | Creation timestamp |
| `updated_at` | `timestamptz` | | Last update timestamp |

**Indexes:**
- Primary key on `id`
- Index on `news_id`
- Index on `user_id`
- Index on `created_at DESC`

**Relationships:**
- Many-to-one with `news`
- Many-to-one with `profiles` (user)

---

### 4. `votes` (Votes Table)

User votes on news articles. One vote per user per news article (enforced by unique constraint).

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| `id` | `bigint` | PRIMARY KEY, GENERATED | Auto-increment ID |
| `news_id` | `bigint` | NOT NULL, FK → `news(id)` | News article voted on |
| `user_id` | `uuid` | NOT NULL, FK → `profiles(id)` | User who voted |
| `vote_type` | `vote_type` | NOT NULL | Vote type: FAKE, NOT_FAKE |
| `created_at` | `timestamptz` | NOT NULL, DEFAULT now() | Creation timestamp |
| `updated_at` | `timestamptz` | | Last update timestamp |

**Indexes:**
- Primary key on `id`
- Unique constraint on `(news_id, user_id)` - ensures one vote per user per news
- Index on `news_id`
- Index on `user_id`

**Relationships:**
- Many-to-one with `news`
- Many-to-one with `profiles` (user)

---

## Image Storage

Images are stored in the backend storage system:
- **News Images**: Stored in `/uploads/news/` folder
- **Comment Images**: Stored in `/uploads/comments/` folder
- **Profile Images**: Stored in `/uploads/profiles/` folder

Image URLs are stored as text in the database, pointing to the backend storage endpoint.

---

## Row Level Security (RLS)

All tables have RLS enabled:

### Profiles
- **SELECT**: Anyone can read profiles
- **UPDATE**: Users can only update their own profile

### News
- **SELECT**: Only non-deleted news is visible
- **INSERT**: Authenticated users can create news (as reporter)
- **UPDATE**: Only reporter can update their news

### Comments
- **SELECT**: Only non-deleted comments are visible
- **INSERT**: Authenticated users can create comments

### Votes
- **SELECT**: All votes are visible
- **INSERT**: Authenticated users can create votes
- **UPDATE**: Users can only update their own votes

---

## Backend API Structure

### Base URL
- Development: `http://localhost:8080/api`
- Production: Set via `VITE_API_BASE_URL` environment variable

### Endpoints

#### News API
- `GET /api/news` - Get all news (paginated)
- `GET /api/news/{id}` - Get news by ID
- `GET /api/news/search?searchTerm=...` - Search news
- `GET /api/news/status/{status}` - Get news by status
- `POST /api/news` - Create news
- `PUT /api/news/{id}/status?status=...` - Update news status
- `DELETE /api/news/{id}` - Soft delete news
- `GET /api/news/statistics` - Get statistics
- `GET /api/news/reporter/{reporterId}` - Get news by reporter

#### Comment API
- `GET /api/news/{newsId}/comments` - Get comments for news
- `POST /api/news/{newsId}/comments` - Create comment
- `DELETE /api/news/{newsId}/comments/{commentId}` - Soft delete comment
- `PUT /api/news/{newsId}/comments/{commentId}/restore` - Restore comment

#### Vote API
- `POST /api/news/{newsId}/votes` - Submit/update vote
- `GET /api/news/{newsId}/votes` - Get votes for news

#### User/Profile API
- `GET /api/users` - Get all users
- `GET /api/users/{id}` - Get user by ID
- `POST /api/users/register` - Register new user
- `PUT /api/users/{id}/upgrade` - Upgrade to admin
- `PUT /api/users/{id}/make-member` - Make member

#### Image Upload API
- `POST /api/upload/image` - Upload image (multipart/form-data)

---

## Frontend Data Mapping

### News Object (Frontend)
```javascript
{
  id: Long,
  title: String,
  shortDetail: String,
  fullDetail: String,
  image: String (URL),
  reporter: String (full name or username),
  reporterId: UUID,
  createdAt: ISO String,
  status: 'fake' | 'notFake' | 'undecided',
  softDeleted: Boolean,
  votes: {
    fake: Number,
    notFake: Number
  },
  comments: Array<Comment>
}
```

### Comment Object (Frontend)
```javascript
{
  id: Long,
  author: String,
  user: String,
  text: String,
  imageUrl: String,
  voteType: 'FAKE' | 'NOT_FAKE' | null,
  vote: 'fake' | 'notFake' | null,
  createdAt: ISO String,
  softDeleted: Boolean
}
```

### User/Profile Object (Frontend)
```javascript
{
  id: UUID,
  username: String,
  email: String,
  firstName: String,
  lastName: String,
  fullName: String,
  imageUrl: String,
  role: 'READER' | 'MEMBER' | 'ADMIN',
  createdAt: ISO String,
  updatedAt: ISO String
}
```

---

## Notes

1. **UUID vs Long IDs**: 
   - User/Profile IDs are UUIDs (from Supabase Auth)
   - News, Comment, and Vote IDs are Long (bigint)

2. **Soft Delete**: 
   - All tables support soft delete via `soft_deleted` flag
   - Soft-deleted records are excluded from normal queries

3. **Status Calculation**: 
   - News status is automatically calculated from votes
   - If `fake` votes > `notFake` votes → status = FAKE
   - If `notFake` votes > `fake` votes → status = NOT_FAKE
   - Otherwise → status = UNDECIDED

4. **One Vote Per User**: 
   - Enforced by unique constraint on `(news_id, user_id)`
   - Users can update their existing vote

5. **Timestamps**: 
   - All tables use `timestamptz` (timezone-aware)
   - `created_at` is auto-set on insert
   - `updated_at` is auto-updated via trigger

---

**Last Updated**: 2025-01-20
**Version**: 2.0.0

